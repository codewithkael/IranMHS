package com.topapp.malek.iranmhs;

public class spval {
    public int ID = 1;
    public String text = "salam";
    @Override
    public String toString() {
        return text;
    }
}
