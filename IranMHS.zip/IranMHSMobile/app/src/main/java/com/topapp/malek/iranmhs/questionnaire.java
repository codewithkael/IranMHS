package com.topapp.malek.iranmhs;

public class questionnaire {
   public String QTitle;
   public String QCode;
   public String Qdesc;
   public int QID;
   public int imgid;
}
