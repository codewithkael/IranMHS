package com.topapp.malek.iranmhs;

public class platecls {

int userid;
int clueid;
String plateadd;
String platepostalcode;
int platenumber;
int platestatus;



}
