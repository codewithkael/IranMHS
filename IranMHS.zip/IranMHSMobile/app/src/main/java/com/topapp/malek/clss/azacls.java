package com.topapp.malek.clss;

public class azacls {




        public int azaid;
        public String  name;
        public  int sal;
        public String  sex;
        public String  irani;
        public String  monaseb;
        public String  hozor;
        public String  hozordesc;
        public String  farsi;
        public int  selected;

        public int  clueid;
        public int  platenumber;
    }