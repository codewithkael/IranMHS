package com.topapp.malek.iranmhs;

public class answer {
    int answerid;
    int QID;
    int QuestionID;
    int UserID;
    String AnswerData;
    String AnswerMeta;

}
