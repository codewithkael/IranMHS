package com.topapp.malek.clss;

public class hamahangicls {



        public int hamid;
        public String  tarikh;

        public String  type;
        public String  nesbat;
        public String  natije;


        public int  clueid;
        public int  platenumber;
    }