package com.topapp.malek.iranmhs;

public class tagStuff {
    String id ="";
    String code ="";
}
