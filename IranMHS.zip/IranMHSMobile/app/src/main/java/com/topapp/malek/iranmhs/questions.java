package com.topapp.malek.iranmhs;

public class questions {
    public String QTitle;
    public String Qorder;
    public String QCode;
    public String QDesctiption;
    public String Prerequisites;
    public String MetaData;
    public String RQ;

    public int QID;
    public int QnID;
    public int QType;
}
