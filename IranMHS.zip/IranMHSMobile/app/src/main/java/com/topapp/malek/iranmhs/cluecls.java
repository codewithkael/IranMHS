package com.topapp.malek.iranmhs;

public class cluecls {
    public int id;
    public String title;
    public String cityname;
    public String provincename;
    public String bakhsh;
    public String deh;
    public String abadi;

    public String clueaddress;
    public String clueloc;
    public String postalcode;
    public int cityid;
    public int provinceid;
    public int clueplatenumbers;
    public int cluestatus;
    public boolean isenable;
}

