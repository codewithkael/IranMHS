package com.topapp.malek.clss;

public class morajeeecls {
    public int morajeeid;
    public int clueid;
    public int platenumber;
    public  String tarikh;
    public  String vaziat;
}
