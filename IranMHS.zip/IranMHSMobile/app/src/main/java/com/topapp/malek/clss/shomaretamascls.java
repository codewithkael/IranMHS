package com.topapp.malek.clss;

public class shomaretamascls {

        public int shomareid;
        public String  noee;
        public String  shomare;
        public String  tozihat;
        public int  clueid;
        public int  platenumber;

    }